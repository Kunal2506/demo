/* global angular */
(function() {


    var app = angular.module('angularApp', []);

    app.controller('SidebarController', function($scope) {

        //breadcrumbs code

        $scope.breadcrumbs = [{
                page: "dashboard",
                title: "Dashboard",
                glyphicon: "dashboard"
            },
            {
                page: "ui",
                title: "t4mbr3",
                glyphicon: "file"
            },
            {
                page: "phonebook",
                title: "Add Dataset",
                glyphicon: "plus"
            }
        ]

        //menu navigation code
        $scope.menuItems = [{

                "href": "#/",
                "text": "Link 1"
            },
            {

                "href": "#page-2",
                "text": "Link 2"
            }
        ];


        $scope.state = false;

        $scope.toggleState = function() {
            $scope.state = !$scope.state;
        };

    });

    app.directive('sidebarDirective', function() {
        return {
            link: function(scope, element, attr) {
                scope.$watch(attr.sidebarDirective, function(newVal) {
                    if (newVal) {
                        element.addClass('show');
                        return;
                    }
                    element.removeClass('show');
                });
            }
        };
    });


    //dropdown controller code

    app.controller('addDataSet', function($scope) {

        $scope.dataSource = [
            "Option 1",
            "Option 2"
        ];

        $scope.datasetValues = [{
            name: "Option 1",
            values: [
                "Dropdown",
                "fileUpload"
            ]
        }, {
            name: "Option 2",
            values: [
                "Option 2.1",
                "Option 2.2"
            ]
        }];
        $scope.names = ["Value 1", "Value 2", "Value 3"];

        $scope.selectedDataSourrce = "";
        $scope.datasetTypeValues = [];
        $scope.datasetType = "";

        $scope.$watch('selectedDataSourrce', function(newValue) {
            for (var i = 0; i < $scope.datasetValues.length; i++) {
                if ($scope.datasetValues[i].name === newValue) {
                    $scope.datasetTypeValues = $scope.datasetValues[i].values;
                }
            }
        });

        //dropdown content add button

        $scope.arr = [];



        $scope.add = function() {
            
         var ar = {
        selectedDataSourrce: $scope.selectedDataSourrce,
        datasetType: $scope.datasetType,
        datasetTable: $scope.datasetTable,
        
    };

    $scope.arr.push(ar);
  };

        $scope.del = function(selectedDataSourrce) {
            
            var comArr = eval($scope.arr);
            for (var i = 0; i < comArr.length; i++) {
                if (comArr[i].selectedDataSourrce === selectedDataSourrce) {
                    index = i;
                    break;
                }
            }
                     
            $scope.arr.splice(index, 1);
        };
        $scope.addExistingData = function() {
            $scope.arr1 = $scope.arr;
        };
        $scope.delExistingData = function(selectedDataSourrce) {
           
             var comArr1 = eval($scope.arr1);
            for (var i = 0; i < comArr1.length; i++) {
                if (comArr1[i].selectedDataSourrce === selectedDataSourrce) {
                    index = i;
                    break;
                }
            }
                     
            $scope.arr1.splice(index, 1);
        };
        
    });
}());

var myApp = angular.module('myFilter', ['ui.bootstrap']);
var myApp = angular.module('myFilter').controller('sourceFilter', function($scope) {

    $scope.filterData = ['Date Range', 'Number Range'];
    $scope.dateFormat = ['DD/MM/YY', 'MM/DD/YYYY'];
    $scope.columns = ['one', 'two'];

    // Accordion Code
    $scope.groups = [];

    $scope.filterOptions = function() {
        if ($scope.addFilter == "Date Range")

        {

            $scope.groups.push({
                title: 'Date Range Filter',
                templateUrl: 'dateRangeFilter.html'
            });
        } else {

            $scope.groups.push({
                title: 'Number Range Filter',
                templateUrl: 'numberRangeFilter.html'
            });

        }
    };

    $scope.delFilter = function(item) {

        var index = $scope.groups.indexOf(item);
        $scope.groups.splice(index, 1);

    };
});